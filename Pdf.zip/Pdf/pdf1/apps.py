from django.apps import AppConfig


class Pdf1Config(AppConfig):
    name = 'pdf1'
